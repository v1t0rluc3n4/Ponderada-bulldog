from glob import glob
from setuptools import find_packages, setup

package_name = "bulldog_drawer"

setup(
    name=package_name,
    version="1.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name + "/images", glob("images/*")),
        ("share/" + package_name + "/launch", glob("launch/*.py")),
    ],
    install_requires=["setuptools", "numpy", "opencv-python-headless"],
    zip_safe=True,
    maintainer="Student",
    maintainer_email="student@example.com",
    description="Extrai contornos de imagem e desenha no turtlesim via ROS 2",
    license="MIT",
    entry_points={
        "console_scripts": [
            "draw_contour = bulldog_drawer.contour_drawer:main",
            "draw_bulldog = bulldog_drawer.draw_bulldog:main",
        ],
    },
)
