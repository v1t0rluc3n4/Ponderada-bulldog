"""Ponto de entrada do pacote (alias para contour_drawer)."""

from .contour_drawer import main

__all__ = ["main"]
