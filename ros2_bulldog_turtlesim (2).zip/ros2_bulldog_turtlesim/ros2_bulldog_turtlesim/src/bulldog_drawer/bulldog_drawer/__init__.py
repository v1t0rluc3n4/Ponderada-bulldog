"""Pacote bulldog_drawer — contorno de imagem no turtlesim."""
