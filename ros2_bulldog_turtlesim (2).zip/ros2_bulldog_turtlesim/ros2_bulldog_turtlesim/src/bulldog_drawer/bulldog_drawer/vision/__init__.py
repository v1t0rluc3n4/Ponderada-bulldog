"""Visão computacional implementada do zero (NumPy + OpenCV apenas para leitura)."""

from .pipeline import ContourPipeline, PipelineResult

__all__ = ["ContourPipeline", "PipelineResult"]
