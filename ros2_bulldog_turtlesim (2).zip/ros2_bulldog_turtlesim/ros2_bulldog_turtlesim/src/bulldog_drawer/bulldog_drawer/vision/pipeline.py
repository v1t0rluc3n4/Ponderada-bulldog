"""Pipeline completo: carregar imagem, processar e obter caminho para turtlesim."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from .contours import extract_main_contour, extract_silhouette_mask
from .edges import canny_edge_detect
from .mapping import map_contour_to_turtlesim
from .preprocess import preprocess


@dataclass
class PipelineResult:
    """Resultados intermediarios e finais do processamento."""

    image_bgr: np.ndarray
    grayscale: np.ndarray
    preprocessed: np.ndarray
    sobel_magnitude: np.ndarray
    threshold: np.ndarray
    edge_map: np.ndarray
    contour_image: list[tuple[float, float]]
    turtlesim_path: list[tuple[float, float]]
    meta: dict


class ContourPipeline:
    """Orquestra pre-processamento, deteccao de bordas e planejamento de caminho."""

    def __init__(
        self,
        image_path: str | Path,
        canny_low_ratio: float = 0.12,
        canny_high_ratio: float = 0.28,
        simplify_epsilon: float = 2.0,
        subsample_step: int = 5,
    ):
        self.image_path = Path(image_path)
        self.canny_low_ratio = canny_low_ratio
        self.canny_high_ratio = canny_high_ratio
        self.simplify_epsilon = simplify_epsilon
        self.subsample_step = subsample_step

    def load_image(self) -> np.ndarray:
        """OpenCV e usado exclusivamente para leitura do arquivo."""
        image = cv2.imread(str(self.image_path))
        if image is None:
            raise FileNotFoundError(f"Nao foi possivel carregar a imagem: {self.image_path}")
        return image

    def run(self) -> PipelineResult:
        image_bgr = self.load_image()
        h, w = image_bgr.shape[:2]

        preprocessed, pre_meta = preprocess(image_bgr)
        edge_map, edge_meta = canny_edge_detect(
            preprocessed,
            low_ratio=self.canny_low_ratio,
            high_ratio=self.canny_high_ratio,
        )
        silhouette = extract_silhouette_mask(preprocessed)
        contour_image = extract_main_contour(
            silhouette,
            epsilon=self.simplify_epsilon,
            step=self.subsample_step,
        )
        turtlesim_path = map_contour_to_turtlesim(contour_image, w, h)

        magnitude = edge_meta["magnitude"]
        mag_max = float(magnitude.max()) + 1e-6
        sobel_vis = np.clip(magnitude * (255.0 / mag_max), 0, 255).astype(np.uint8)

        meta = {"preprocess": pre_meta, "edges": edge_meta}
        return PipelineResult(
            image_bgr=image_bgr,
            grayscale=pre_meta["gray"],
            preprocessed=preprocessed,
            sobel_magnitude=sobel_vis,
            threshold=edge_map,
            edge_map=edge_map,
            contour_image=contour_image,
            turtlesim_path=turtlesim_path,
            meta=meta,
        )
