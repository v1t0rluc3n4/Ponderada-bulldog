"""Detector de bordas Canny implementado do zero (Sobel + NMS + histerese)."""

from __future__ import annotations

import math

import numpy as np

from .preprocess import convolve2d


SOBEL_X = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float64)
SOBEL_Y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float64)

# Vizinhanca 8-conectada para rastreamento de histerese
NEIGHBORS_8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def sobel_gradients(image: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Calcula gradientes Gx, Gy e magnitude via operadores de Sobel."""
    gx = convolve2d(image, SOBEL_X)
    gy = convolve2d(image, SOBEL_Y)
    magnitude = np.hypot(gx, gy)
    return gx, gy, magnitude


def non_maximum_suppression(magnitude: np.ndarray, gx: np.ndarray, gy: np.ndarray) -> np.ndarray:
    """Suprime pixels que nao sao maximos locais na direcao do gradiente."""
    h, w = magnitude.shape
    angle = np.arctan2(gy, gx)
    suppressed = np.zeros((h, w), dtype=np.float64)

    for y in range(1, h - 1):
        for x in range(1, w - 1):
            m = magnitude[y, x]
            if m < 1e-6:
                continue
            a = angle[y, x]
            # Quantiza em 4 direcoes (0, 45, 90, 135 graus)
            deg = (math.degrees(a) + 180.0) % 180.0
            if deg < 22.5 or deg >= 157.5:
                n1, n2 = magnitude[y, x - 1], magnitude[y, x + 1]
            elif deg < 67.5:
                n1, n2 = magnitude[y - 1, x + 1], magnitude[y + 1, x - 1]
            elif deg < 112.5:
                n1, n2 = magnitude[y - 1, x], magnitude[y + 1, x]
            else:
                n1, n2 = magnitude[y - 1, x - 1], magnitude[y + 1, x + 1]
            if m >= n1 and m >= n2:
                suppressed[y, x] = m
    return suppressed


def double_threshold(suppressed: np.ndarray, low_ratio: float = 0.12, high_ratio: float = 0.28) -> np.ndarray:
    """
    Limiar duplo adaptativo baseado em percentis da magnitude.

    Razoes mais altas que o Canny classico reduzem detalhes internos
    (coleira, textura do pelo) e privilegiam o contorno principal.
    """
    nonzero = suppressed[suppressed > 0]
    if nonzero.size == 0:
        return np.zeros_like(suppressed, dtype=np.uint8)
    high = np.percentile(nonzero, high_ratio * 100.0)
    low = np.percentile(nonzero, low_ratio * 100.0)
    if high <= low:
        high = low * 2.0

    strong = suppressed >= high
    weak = (suppressed >= low) & ~strong
    h, w = suppressed.shape
    edges = np.zeros((h, w), dtype=np.uint8)
    edges[strong] = 255

    stack = [(y, x) for y in range(h) for x in range(w) if strong[y, x]]
    while stack:
        y, x = stack.pop()
        for dy, dx in NEIGHBORS_8:
            ny, nx = y + dy, x + dx
            if 0 <= ny < h and 0 <= nx < w and weak[ny, nx] and edges[ny, nx] == 0:
                edges[ny, nx] = 255
                stack.append((ny, nx))
    return edges


def morph_dilate(binary: np.ndarray, iterations: int = 1) -> np.ndarray:
    """Dilatacao binaria 3x3 para fechar pequenas quebras no contorno."""
    src = (binary > 0).astype(np.uint8)
    out = src.copy()
    h, w = src.shape
    for _ in range(iterations):
        temp = out.copy()
        for y in range(1, h - 1):
            for x in range(1, w - 1):
                if np.any(temp[y - 1 : y + 2, x - 1 : x + 2]):
                    out[y, x] = 1
    return (out * 255).astype(np.uint8)


def canny_edge_detect(
    image: np.ndarray,
    low_ratio: float = 0.12,
    high_ratio: float = 0.28,
) -> tuple[np.ndarray, dict]:
    """Pipeline Canny completo."""
    gx, gy, magnitude = sobel_gradients(image)
    suppressed = non_maximum_suppression(magnitude, gx, gy)
    edges = double_threshold(suppressed, low_ratio=low_ratio, high_ratio=high_ratio)
    edges = morph_dilate(edges, iterations=1)
    meta = {"gx": gx, "gy": gy, "magnitude": magnitude, "suppressed": suppressed}
    return edges, meta
