"""Extracao, ordenacao e simplificacao de contornos."""

from __future__ import annotations

import math

import numpy as np

from .edges import morph_dilate

NEIGHBORS_8 = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def label_connected_components(binary: np.ndarray) -> tuple[np.ndarray, dict[int, int]]:
    """Rotula componentes conexos 8-vizinhos e retorna tamanhos por rotulo."""
    mask = binary > 0
    h, w = mask.shape
    labels = np.zeros((h, w), dtype=np.int32)
    sizes: dict[int, int] = {}
    current = 0

    for y in range(h):
        for x in range(w):
            if not mask[y, x] or labels[y, x] != 0:
                continue
            current += 1
            count = 0
            stack = [(y, x)]
            labels[y, x] = current
            while stack:
                cy, cx = stack.pop()
                count += 1
                for dy, dx in NEIGHBORS_8:
                    ny, nx = cy + dy, cx + dx
                    if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] and labels[ny, nx] == 0:
                        labels[ny, nx] = current
                        stack.append((ny, nx))
            sizes[current] = count
    return labels, sizes


def keep_largest_component(binary: np.ndarray) -> np.ndarray:
    """Mantem apenas o maior componente (silhueta principal do objeto)."""
    labels, sizes = label_connected_components(binary)
    if not sizes:
        return binary.copy()
    main_label = max(sizes, key=sizes.get)
    out = np.zeros_like(binary)
    out[labels == main_label] = 255
    return out


def extract_silhouette_mask(
    gray: np.ndarray,
    percentile: float = 38.0,
    bottom_crop_ratio: float = 0.26,
    right_crop_ratio: float = 0.30,
) -> np.ndarray:
    """
    Mascara binaria do objeto escuro (bulldog) sobre fundo claro.
    Recorta o rodape da foto para nao incluir o piso no contorno.
    """
    h, w = gray.shape
    crop_h = max(1, int(h * (1.0 - bottom_crop_ratio)))
    work = gray[:crop_h, :]
    threshold = float(np.percentile(work, percentile))
    binary = np.where(work < threshold, 255, 0).astype(np.uint8)
    sil = keep_largest_component(binary)
    right_cut = int(w * (1.0 - right_crop_ratio))
    sil[:, right_cut:] = 0
    sil = keep_largest_component(sil)
    sil = _morph_erode(sil, 3)
    sil = morph_dilate(sil, 2)
    full = np.zeros((h, w), dtype=np.uint8)
    full[:crop_h, :] = sil
    return full


def _morph_erode(binary: np.ndarray, iterations: int = 1) -> np.ndarray:
    src = (binary > 0).astype(np.uint8)
    out = src.copy()
    h, w = src.shape
    for _ in range(iterations):
        temp = out.copy()
        for y in range(1, h - 1):
            for x in range(1, w - 1):
                out[y, x] = 1 if np.all(temp[y - 1 : y + 2, x - 1 : x + 2]) else 0
    return (out * 255).astype(np.uint8)


def outer_boundary_mask(binary: np.ndarray) -> np.ndarray:
    mask = binary > 0
    h, w = mask.shape
    boundary = np.zeros((h, w), dtype=np.uint8)
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            if not mask[y, x]:
                continue
            if not (mask[y - 1, x] and mask[y + 1, x] and mask[y, x - 1] and mask[y, x + 1]):
                boundary[y, x] = 255
    return boundary


def trace_outer_boundary_filled(binary: np.ndarray) -> list[tuple[int, int]]:
    """
    Rastreia o contorno externo da silhueta preenchida (algoritmo de Moore).
    """
    filled = keep_largest_component(binary) > 0
    h, w = filled.shape
    ys_all, xs_all = np.where(filled)
    if xs_all.size == 0:
        return []
    top_y = int(ys_all.min())
    top_xs = xs_all[ys_all == top_y]
    start = (int(np.median(top_xs)), top_y)

    dirs = [(-1, 0), (-1, 1), (0, 1), (1, 1), (1, 0), (1, -1), (0, -1), (-1, -1)]
    contour = [start]
    x, y = start
    dir_i = 6

    for _ in range(int(filled.sum()) * 4 + 20):
        moved = False
        for k in range(8):
            check = (dir_i + 7 - k) % 8
            dx, dy = dirs[check]
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h and filled[ny, nx]:
                x, y = nx, ny
                dir_i = check
                contour.append((x, y))
                moved = True
                break
        if not moved:
            break
        if len(contour) > 3 and (x, y) == start:
            break
    return contour


def trace_boundary_chain(boundary: np.ndarray) -> list[tuple[int, int]]:
    """
    Segue pixels de borda 8-conectados em ordem continua (vizinho mais alinhado).
    """
    ys, xs = np.where(boundary > 0)
    if xs.size < 3:
        return []

    points = set(zip(xs.tolist(), ys.tolist()))
    start = min(points, key=lambda p: (p[1], p[0]))
    path: list[tuple[int, int]] = [start]
    visited = {start}
    current = start
    prev_dir = (0, -1)

    for _ in range(len(points) * 3):
        cx, cy = current
        candidates = []
        for dx, dy in NEIGHBORS_8:
            nxt = (cx + dx, cy + dy)
            if nxt in points and nxt not in visited:
                candidates.append(nxt)

        if not candidates:
            break

        pdx, pdy = prev_dir
        best = max(candidates, key=lambda n: (n[0] - cx) * pdx + (n[1] - cy) * pdy)
        if best == start and len(path) > 20:
            break

        prev_dir = (best[0] - cx, best[1] - cy)
        path.append(best)
        visited.add(best)
        current = best

    if len(path) < 20:
        return []
    return path


def trace_boundary_moore(boundary: np.ndarray) -> list[tuple[int, int]]:
    """Rastreamento Moore na mascara de borda (1 pixel)."""
    mask = boundary > 0
    h, w = mask.shape
    ys, xs = np.where(mask)
    if ys.size == 0:
        return []

    start = min(zip(xs.tolist(), ys.tolist()), key=lambda p: (p[1], p[0]))
    start_x, start_y = start
    directions = [(1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)]
    dir_index = 7

    contour: list[tuple[int, int]] = []
    cx, cy = start_x, start_y
    max_steps = int(mask.sum()) * 4 + 20

    for _ in range(max_steps):
        contour.append((cx, cy))
        found = False
        for k in range(8):
            idx = (dir_index + k) % 8
            dx, dy = directions[idx]
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < w and 0 <= ny < h and mask[ny, nx]:
                dir_index = (idx + 5) % 8
                cx, cy = nx, ny
                found = True
                break
        if not found:
            break
        if len(contour) > 3 and (cx, cy) == (start_x, start_y):
            break

    return contour


def douglas_peucker(points: list[tuple[float, float]], epsilon: float) -> list[tuple[float, float]]:
    """Simplifica polilinha preservando forma."""
    if len(points) < 3:
        return points

    def perpendicular_distance(point, start, end):
        x0, y0 = point
        x1, y1 = start
        x2, y2 = end
        dx, dy = x2 - x1, y2 - y1
        if dx == 0 and dy == 0:
            return math.hypot(x0 - x1, y0 - y1)
        num = abs(dy * x0 - dx * y0 + x2 * y1 - y2 * x1)
        den = math.hypot(dx, dy)
        return num / den

    def rdp(pts: list[tuple[float, float]]) -> list[tuple[float, float]]:
        if len(pts) < 3:
            return pts
        start, end = pts[0], pts[-1]
        index = -1
        dist_max = 0.0
        for i in range(1, len(pts) - 1):
            d = perpendicular_distance(pts[i], start, end)
            if d > dist_max:
                index = i
                dist_max = d
        if dist_max > epsilon:
            left = rdp(pts[: index + 1])
            right = rdp(pts[index:])
            return left[:-1] + right
        return [start, end]

    return rdp(points)


def remove_bottom_band(
    points: list[tuple[int, int]],
    silhouette: np.ndarray,
    band_ratio: float = 0.2,
) -> list[tuple[int, int]]:
    """Remove trecho do contorno que passa pelo piso (faixa inferior da silhueta)."""
    ys, xs = np.where(silhouette > 0)
    if xs.size == 0 or len(points) < 20:
        return points
    y_min, y_max = int(ys.min()), int(ys.max())
    y_cut = int(y_max - band_ratio * (y_max - y_min))
    kept = [(x, y) for x, y in points if y <= y_cut]
    return kept if len(kept) >= 20 else points


def clip_to_silhouette_bbox(
    points: list[tuple[int, int]],
    silhouette: np.ndarray,
    margin: int = 8,
) -> list[tuple[int, int]]:
    """Mantem apenas pontos dentro da caixa do objeto (evita rastro no piso/lateral)."""
    ys, xs = np.where(silhouette > 0)
    if xs.size == 0 or len(points) < 20:
        return points
    x0, x1 = int(xs.min()) - margin, int(xs.max()) + margin
    y0, y1 = int(ys.min()) - margin, int(ys.max()) + margin
    kept = [(x, y) for x, y in points if x0 <= x <= x1 and y0 <= y <= y1]
    return kept if len(kept) >= 20 else points


def subsample(points: list[tuple[float, float]], step: int = 4) -> list[tuple[float, float]]:
    if step <= 1 or len(points) <= 2:
        return points
    sampled = points[::step]
    if sampled[-1] != points[-1]:
        sampled.append(points[-1])
    return sampled


def extract_main_contour(
    binary: np.ndarray,
    epsilon: float = 2.5,
    step: int = 3,
) -> list[tuple[float, float]]:
    """Seleciona maior componente, rastreia contorno externo e simplifica."""
    cleaned = keep_largest_component(binary)
    boundary = trace_outer_boundary_filled(cleaned)
    boundary = clip_to_silhouette_bbox(boundary, cleaned)
    if len(boundary) < 80:
        thin = outer_boundary_mask(cleaned)
        boundary = trace_boundary_moore(thin)
    if len(boundary) < 20:
        thin = outer_boundary_mask(cleaned)
        ys, xs = np.where(thin > 0)
        boundary = list(zip(xs.tolist(), ys.tolist()))

    points = [(float(x), float(y)) for x, y in boundary]
    points = subsample(points, step=step)
    points = douglas_peucker(points, epsilon=epsilon)

    if len(points) < 20:
        raw = [(float(x), float(y)) for x, y in boundary]
        points = subsample(raw, step=max(2, step - 1))
        points = douglas_peucker(points, epsilon=max(1.0, epsilon * 0.6))

    return points
