﻿"""Pre-processamento de imagem."""

from __future__ import annotations
import numpy as np

def rgb_to_grayscale(image_bgr):
    b = image_bgr[:, :, 0].astype(np.float64)
    g = image_bgr[:, :, 1].astype(np.float64)
    r = image_bgr[:, :, 2].astype(np.float64)
    gray = 0.114 * b + 0.587 * g + 0.299 * r
    return np.clip(gray, 0, 255).astype(np.float64)

def gaussian_kernel_1d(size, sigma):
    if size % 2 == 0:
        raise ValueError("kernel impar")
    radius = size // 2
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-(x ** 2) / (2.0 * sigma ** 2))
    kernel /= np.sum(kernel)
    return kernel

def convolve2d(image, kernel, mode="reflect"):
    kh, kw = kernel.shape
    pad_y, pad_x = kh // 2, kw // 2
    src = image.astype(np.float64)
    padded = np.pad(src, ((pad_y, pad_y), (pad_x, pad_x)), mode="reflect" if mode=="reflect" else "constant")
    out = np.zeros_like(src)
    h, w = src.shape
    flipped = np.flipud(np.fliplr(kernel))
    for y in range(h):
        for x in range(w):
            out[y, x] = np.sum(padded[y:y+kh, x:x+kw] * flipped)
    return out

def convolve_separable(image, kernel_1d):
    k = kernel_1d.reshape(1, -1)
    return convolve2d(convolve2d(image, k), k.T)

def gaussian_blur(image, kernel_size=7, sigma=1.8):
    return convolve_separable(image, gaussian_kernel_1d(kernel_size, sigma))

def normalize_contrast(image, low_pct=2.0, high_pct=98.0):
    low = np.percentile(image, low_pct)
    high = np.percentile(image, high_pct)
    if high <= low:
        return image.copy()
    return np.clip((image - low) * (255.0 / (high - low)), 0, 255)

def preprocess(image_bgr):
    gray = normalize_contrast(rgb_to_grayscale(image_bgr))
    blurred = gaussian_blur(gray, 7, 1.8)
    return blurred, {"gray": gray, "blurred": blurred}
