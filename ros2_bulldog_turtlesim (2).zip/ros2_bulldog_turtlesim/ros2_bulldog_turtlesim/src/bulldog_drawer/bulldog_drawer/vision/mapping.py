"""Mapeamento de coordenadas da imagem para o espaco do turtlesim."""

from __future__ import annotations

import numpy as np


def map_contour_to_turtlesim(
    contour_xy: list[tuple[float, float]],
    image_width: int,
    image_height: int,
    margin: float = 0.8,
    world_min: float = 0.5,
    world_max: float = 10.5,
) -> list[tuple[float, float]]:
    """
    Normaliza o contorno para caber na area util do turtlesim (aprox. 11x11).

    - Inverte o eixo Y (imagem: origem no topo; turtlesim: origem embaixo).
    - Centraliza e escala uniformemente preservando aspect ratio.
    """
    if not contour_xy:
        return []

    xs = np.array([p[0] for p in contour_xy], dtype=np.float64)
    ys = np.array([p[1] for p in contour_xy], dtype=np.float64)

    min_x, max_x = xs.min(), xs.max()
    min_y, max_y = ys.min(), ys.max()
    span_x = max(max_x - min_x, 1.0)
    span_y = max(max_y - min_y, 1.0)

    usable = world_max - world_min - 2.0 * margin
    scale = usable / max(span_x, span_y)

    cx = (min_x + max_x) / 2.0
    cy = (min_y + max_y) / 2.0
    world_cx = (world_min + world_max) / 2.0
    world_cy = (world_min + world_max) / 2.0

    mapped: list[tuple[float, float]] = []
    for x, y in contour_xy:
        nx = (x - cx) * scale + world_cx
        ny = world_cy - (y - cy) * scale
        mapped.append((float(nx), float(ny)))
    return mapped
