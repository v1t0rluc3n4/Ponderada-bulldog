"""No ROS 2: controla a tartaruga do turtlesim para desenhar o contorno processado."""

from __future__ import annotations

import json
import math
import time
from pathlib import Path

import rclpy
from ament_index_python.packages import get_package_share_directory
from geometry_msgs.msg import Twist
from rclpy.node import Node
from turtlesim.msg import Pose
from turtlesim.srv import SetPen, TeleportAbsolute

from .vision.pipeline import ContourPipeline


def normalize_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


class ContourDrawer(Node):
    """Segue waypoints no turtlesim com controle proporcional simples."""

    def __init__(self) -> None:
        super().__init__("contour_drawer")
        self.declare_parameter("image_path", "")
        self.declare_parameter("linear_speed", 3.0)
        self.declare_parameter("angular_gain", 4.0)
        self.declare_parameter("goal_tolerance", 0.1)
        self.declare_parameter("jump_threshold", 1.2)
        self.declare_parameter("pen_r", 220)
        self.declare_parameter("pen_g", 40)
        self.declare_parameter("pen_b", 40)
        self.declare_parameter("pen_width", 3)
        self.declare_parameter("save_path_json", "")
        self.declare_parameter("subsample_step", 8)
        self.declare_parameter("simplify_epsilon", 2.2)
        self.declare_parameter("turtlesim_wait_sec", 30.0)

        image_path = self._resolve_image_path()
        self.get_logger().info(f"Processando imagem: {image_path}")

        subsample = self.get_parameter("subsample_step").get_parameter_value().integer_value
        epsilon = self.get_parameter("simplify_epsilon").get_parameter_value().double_value
        result = ContourPipeline(
            image_path,
            subsample_step=subsample,
            simplify_epsilon=epsilon,
        ).run()
        self.waypoints = result.turtlesim_path
        if not self.waypoints:
            raise RuntimeError("Nenhum contorno foi extraido da imagem.")

        self.get_logger().info(f"Waypoints para desenho: {len(self.waypoints)}")

        save_json = self.get_parameter("save_path_json").get_parameter_value().string_value
        if save_json:
            Path(save_json).write_text(
                json.dumps(self.waypoints, indent=2),
                encoding="utf-8",
            )

        self.pose: Pose | None = None
        self.cmd_pub = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.create_subscription(Pose, "/turtle1/pose", self._pose_callback, 10)
        self.pen_client = self.create_client(SetPen, "/turtle1/set_pen")
        self.teleport_client = self.create_client(TeleportAbsolute, "/turtle1/teleport_absolute")
        self._wait_for_services()

        self.linear_speed = self.get_parameter("linear_speed").get_parameter_value().double_value
        self.angular_gain = self.get_parameter("angular_gain").get_parameter_value().double_value
        self.goal_tolerance = self.get_parameter("goal_tolerance").get_parameter_value().double_value
        self.jump_threshold = self.get_parameter("jump_threshold").get_parameter_value().double_value

    def _resolve_image_path(self) -> Path:
        custom = self.get_parameter("image_path").get_parameter_value().string_value.strip()
        if custom:
            path = Path(custom)
        else:
            share = Path(get_package_share_directory("bulldog_drawer"))
            path = share / "images" / "bulldog.png"
        if not path.exists():
            raise FileNotFoundError(
                f"Imagem nao encontrada em {path}. "
                "Coloque bulldog.png em bulldog_drawer/images/ ou defina o parametro image_path."
            )
        return path

    def _wait_for_services(self) -> None:
        timeout = self.get_parameter("turtlesim_wait_sec").get_parameter_value().double_value
        for client in (self.pen_client, self.teleport_client):
            elapsed = 0.0
            while not client.wait_for_service(timeout_sec=1.0):
                elapsed += 1.0
                if elapsed >= timeout:
                    raise RuntimeError(
                        f"Servico {client.srv_name} nao encontrado apos {timeout:.0f}s. "
                        "Abra outro terminal e rode: ros2 run turtlesim turtlesim_node "
                        "OU use um unico comando: ros2 launch bulldog_drawer draw_contour.launch.py"
                    )
                if int(elapsed) % 5 == 0:
                    self.get_logger().warn(
                        f"Aguardando {client.srv_name}... ({elapsed:.0f}s) — turtlesim esta rodando?"
                    )

    def _pose_callback(self, msg: Pose) -> None:
        self.pose = msg

    def _spin_until_pose(self) -> None:
        while self.pose is None and rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.1)

    def _stop(self) -> None:
        self.cmd_pub.publish(Twist())

    def _set_pen(self, off: bool) -> None:
        req = SetPen.Request()
        req.off = int(off)
        req.width = int(self.get_parameter("pen_width").get_parameter_value().integer_value)
        req.r = int(self.get_parameter("pen_r").get_parameter_value().integer_value)
        req.g = int(self.get_parameter("pen_g").get_parameter_value().integer_value)
        req.b = int(self.get_parameter("pen_b").get_parameter_value().integer_value)
        future = self.pen_client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)

    def _teleport(self, x: float, y: float, theta: float | None = None) -> None:
        req = TeleportAbsolute.Request()
        req.x = float(x)
        req.y = float(y)
        req.theta = float(self.pose.theta if theta is None and self.pose else 0.0)
        if theta is not None:
            req.theta = float(theta)
        future = self.teleport_client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        self._stop()

    def _go_to(self, target_x: float, target_y: float) -> None:
        """Gira no lugar e depois avanca em linha reta (evita orbitas circulares)."""
        self._spin_until_pose()
        rate = self.create_rate(30)
        turn_gain = min(self.angular_gain, 2.5)

        while rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.05)
            if self.pose is None:
                continue

            dx = target_x - self.pose.x
            dy = target_y - self.pose.y
            distance = math.hypot(dx, dy)
            if distance < self.goal_tolerance:
                self._stop()
                return

            heading_error = normalize_angle(math.atan2(dy, dx) - self.pose.theta)
            cmd = Twist()

            if abs(heading_error) > 0.12:
                cmd.linear.x = 0.0
                cmd.angular.z = max(-2.5, min(2.5, turn_gain * heading_error))
            else:
                cmd.linear.x = min(self.linear_speed, distance)
                cmd.angular.z = 0.4 * heading_error

            self.cmd_pub.publish(cmd)
            rate.sleep()

    def _move_to_waypoint(self, x: float, y: float, previous: tuple[float, float] | None) -> None:
        if previous is not None:
            jump = math.hypot(x - previous[0], y - previous[1])
            if jump > self.jump_threshold:
                self._set_pen(True)
                self._teleport(x, y)
                self._set_pen(False)
                return
        self._go_to(x, y)

    def draw(self) -> None:
        self.get_logger().info("Iniciando desenho no turtlesim...")
        self._spin_until_pose()

        first_x, first_y = self.waypoints[0]
        theta0 = 0.0
        if len(self.waypoints) > 1:
            theta0 = math.atan2(
                self.waypoints[1][1] - first_y,
                self.waypoints[1][0] - first_x,
            )
        self._set_pen(True)
        self._teleport(first_x, first_y, theta0)
        self._set_pen(False)

        previous: tuple[float, float] | None = (first_x, first_y)
        total = len(self.waypoints)
        for i, (x, y) in enumerate(self.waypoints[1:], start=2):
            self._move_to_waypoint(x, y, previous)
            previous = (x, y)
            if i % 25 == 0 or i == total:
                self.get_logger().info(f"Progresso: {i}/{total} pontos")
        self._stop()
        self.get_logger().info("Desenho concluido.")


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ContourDrawer()
    time.sleep(1.0)
    try:
        node.draw()
    finally:
        node.destroy_node()
        rclpy.shutdown()
