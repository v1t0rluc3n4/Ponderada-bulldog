from pathlib import Path

CONTENT = r'''"""Pre-processamento de imagem — convolucoes implementadas manualmente."""

from __future__ import annotations

import numpy as np


def rgb_to_grayscale(image_bgr: np.ndarray) -> np.ndarray:
    """Converte BGR (OpenCV) para escala de cinza com pesos ITU-R BT.601."""
    b = image_bgr[:, :, 0].astype(np.float64)
    g = image_bgr[:, :, 1].astype(np.float64)
    r = image_bgr[:, :, 2].astype(np.float64)
    gray = 0.114 * b + 0.587 * g + 0.299 * r
    return np.clip(gray, 0, 255).astype(np.float64)


def gaussian_kernel_1d(size: int, sigma: float) -> np.ndarray:
    if size % 2 == 0:
        raise ValueError("Tamanho do kernel deve ser impar.")
    radius = size // 2
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-(x ** 2) / (2.0 * sigma ** 2))
    kernel /= np.sum(kernel)
    return kernel


def convolve2d(image: np.ndarray, kernel: np.ndarray, mode: str = "reflect") -> np.ndarray:
    kh, kw = kernel.shape
    pad_y, pad_x = kh // 2, kw // 2
    src = image.astype(np.float64)
    if mode == "reflect":
        padded = np.pad(src, ((pad_y, pad_y), (pad_x, pad_x)), mode="reflect")
    elif mode == "zero":
        padded = np.pad(src, ((pad_y, pad_y), (pad_x, pad_x)), mode="constant")
    else:
        raise ValueError(f"Modo de padding desconhecido: {mode}")
    out = np.zeros_like(src)
    h, w = src.shape
    flipped = np.flipud(np.fliplr(kernel))
    for y in range(h):
        for x in range(w):
            region = padded[y : y + kh, x : x + kw]
            out[y, x] = np.sum(region * flipped)
    return out


def convolve_separable(image: np.ndarray, kernel_1d: np.ndarray) -> np.ndarray:
    k = kernel_1d.reshape(1, -1)
    horizontal = convolve2d(image, k, mode="reflect")
    vertical = convolve2d(horizontal, k.T, mode="reflect")
    return vertical


def gaussian_blur(image: np.ndarray, kernel_size: int = 7, sigma: float = 1.8) -> np.ndarray:
    kernel = gaussian_kernel_1d(kernel_size, sigma)
    return convolve_separable(image, kernel)


def normalize_contrast(image: np.ndarray, low_pct: float = 2.0, high_pct: float = 98.0) -> np.ndarray:
    low = np.percentile(image, low_pct)
    high = np.percentile(image, high_pct)
    if high <= low:
        return image.copy()
    stretched = (image - low) * (255.0 / (high - low))
    return np.clip(stretched, 0, 255)


def preprocess(image_bgr: np.ndarray) -> tuple[np.ndarray, dict]:
    gray = rgb_to_grayscale(image_bgr)
    gray = normalize_contrast(gray)
    blurred = gaussian_blur(gray, kernel_size=7, sigma=1.8)
    meta = {"gray": gray, "blurred": blurred}
    return blurred, meta
'''

target = Path(__file__).parent / "src/bulldog_drawer/bulldog_drawer/vision/preprocess.py"
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(CONTENT, encoding="utf-8")
print("written", target)
