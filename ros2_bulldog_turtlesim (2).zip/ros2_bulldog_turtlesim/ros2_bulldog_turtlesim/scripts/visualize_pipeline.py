#!/usr/bin/env python3
"""Visualiza etapas do pipeline (Original, Grayscale, Sobel, Threshold + Contornos)."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1] / "src" / "bulldog_drawer"
sys.path.insert(0, str(ROOT))

from bulldog_drawer.vision.pipeline import ContourPipeline  # noqa: E402


def _save_rgb(path: Path, rgb: np.ndarray) -> None:
    plt.imsave(path, rgb)


def _save_gray(path: Path, gray: np.ndarray) -> None:
    plt.imsave(path, gray, cmap="gray")


def _save_reference_grid(path: Path, rgb: np.ndarray, result) -> None:
    """Grade 2x2 igual ao projeto de referencia: Original, Grayscale, Sobel, Threshold."""
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    panels = [
        (rgb, "Original", None),
        (result.grayscale, "Grayscale", "gray"),
        (result.sobel_magnitude, "Sobel", "gray"),
        (result.threshold, "Threshold", "gray"),
    ]
    for ax, (data, title, cmap) in zip(axes.flat, panels):
        if cmap:
            ax.imshow(data, cmap=cmap)
        else:
            ax.imshow(data)
        ax.set_title(title)
    plt.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def _save_contornos_detectados(path: Path, threshold: np.ndarray) -> None:
    """Janela 'Contornos Detectados': bordas brancas em fundo preto."""
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.imshow(threshold, cmap="gray", vmin=0, vmax=255)
    ax.set_title("Contornos Detectados")
    fig.patch.set_facecolor("black")
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="black")
    plt.close(fig)


def _save_contour_overlay(path: Path, rgb: np.ndarray, contour: list[tuple[float, float]]) -> None:
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(rgb)
    if contour:
        xs = [p[0] for p in contour]
        ys = [p[1] for p in contour]
        ax.plot(xs, ys, "r-", linewidth=1.5)
    ax.set_title("Contorno sobre a foto")
    ax.axis("off")
    fig.savefig(path, dpi=150, bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def _save_turtlesim_path(path: Path, waypoints: list[tuple[float, float]]) -> None:
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 11)
    ax.set_aspect("equal")
    ax.invert_yaxis()
    ax.grid(True, alpha=0.3)
    if waypoints:
        xs = [p[0] for p in waypoints]
        ys = [p[1] for p in waypoints]
        ax.plot(xs, ys, "b-", linewidth=1.2)
        ax.plot(xs[0], ys[0], "go", markersize=6, label="inicio")
    ax.set_title(f"Caminho turtlesim ({len(waypoints)} pontos)")
    ax.legend(loc="upper right")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def save_all_images(result, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rgb = result.image_bgr[:, :, ::-1]

    files = {
        "01_original.png": lambda p: _save_rgb(p, rgb),
        "02_grayscale.png": lambda p: _save_gray(p, result.grayscale),
        "03_sobel.png": lambda p: _save_gray(p, result.sobel_magnitude),
        "04_threshold.png": lambda p: _save_gray(p, result.threshold),
        "05_contornos_detectados.png": lambda p: _save_contornos_detectados(p, result.threshold),
        "06_pipeline_grid.png": lambda p: _save_reference_grid(p, rgb, result),
        "07_contour_overlay.png": lambda p: _save_contour_overlay(p, rgb, result.contour_image),
        "08_turtlesim_path.png": lambda p: _save_turtlesim_path(p, result.turtlesim_path),
    }

    saved: list[Path] = []
    for name, saver in files.items():
        out = output_dir / name
        saver(out)
        saved.append(out)
        print(f"Salvo: {out}")
    return saved


def show_interactive(rgb: np.ndarray, result) -> None:
    """Abre as duas janelas como no projeto de referencia."""
    fig1, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig1.canvas.manager.set_window_title("Figure 1")
    panels = [
        (rgb, "Original", None),
        (result.grayscale, "Grayscale", "gray"),
        (result.sobel_magnitude, "Sobel", "gray"),
        (result.threshold, "Threshold", "gray"),
    ]
    for ax, (data, title, cmap) in zip(axes.flat, panels):
        if cmap:
            ax.imshow(data, cmap=cmap)
        else:
            ax.imshow(data)
        ax.set_title(title)
    plt.tight_layout()

    fig2, ax2 = plt.subplots(figsize=(10, 8))
    fig2.canvas.manager.set_window_title("Contornos Detectados")
    ax2.imshow(result.threshold, cmap="gray", vmin=0, vmax=255)
    ax2.set_title("Contornos Detectados")
    fig2.patch.set_facecolor("black")

    plt.show()


def main() -> None:
    parser = argparse.ArgumentParser(description="Visualiza Original, Grayscale, Sobel e Threshold.")
    parser.add_argument("image", type=Path, help="Caminho da imagem de entrada")
    parser.add_argument("--output", type=Path, default=None, help="Salva grade 2x2 em arquivo PNG")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Pasta onde salvar todas as imagens do pipeline",
    )
    args = parser.parse_args()

    result = ContourPipeline(args.image).run()
    rgb = result.image_bgr[:, :, ::-1]

    if args.output_dir:
        save_all_images(result, args.output_dir)
    elif args.output:
        _save_reference_grid(args.output, rgb, result)
        print(f"Figura salva em {args.output}")
    else:
        show_interactive(rgb, result)

    print(f"Waypoints turtlesim: {len(result.turtlesim_path)}")


if __name__ == "__main__":
    main()
