#!/usr/bin/env python3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "src" / "bulldog_drawer"
sys.path.insert(0, str(ROOT))

from bulldog_drawer.vision.contours import (  # noqa: E402
    extract_main_contour,
    extract_silhouette_mask,
    trace_boundary_chain,
    outer_boundary_mask,
)
from bulldog_drawer.vision.pipeline import ContourPipeline  # noqa: E402
from bulldog_drawer.vision.preprocess import preprocess  # noqa: E402

img = "src/bulldog_drawer/images/bulldog.png"
r = ContourPipeline(img).run()
pre, _ = preprocess(r.image_bgr)
sil = extract_silhouette_mask(pre)
thin = outer_boundary_mask(sil)
chain = trace_boundary_chain(thin)
print("chain boundary pts", len(chain))
print("contour pts", len(r.contour_image))
print("turtlesim pts", len(r.turtlesim_path))
