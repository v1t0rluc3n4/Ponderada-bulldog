#!/usr/bin/env python3
import sys
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parents[1] / "src" / "bulldog_drawer"
sys.path.insert(0, str(ROOT))

from bulldog_drawer.vision.contours import (  # noqa: E402
    extract_silhouette_mask,
    outer_boundary_mask,
    trace_boundary_chain,
    trace_boundary_moore,
)
from bulldog_drawer.vision.preprocess import preprocess  # noqa: E402

img = cv2.imread("src/bulldog_drawer/images/bulldog.png")
pre, _ = preprocess(img)
for p in [35, 40, 45, 50]:
    sil = extract_silhouette_mask(pre, p)
    thin = outer_boundary_mask(sil)
    print(
        "pct", p,
        "sil", sil.sum() // 255,
        "thin", thin.sum() // 255,
        "chain", len(trace_boundary_chain(thin)),
        "moore", len(trace_boundary_moore(thin)),
    )
