#!/usr/bin/env bash
# Gera todas as imagens do pipeline e executa o desenho no turtlesim (WSL/Ubuntu).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

source /opt/ros/jazzy/setup.bash 2>/dev/null || source /opt/ros/humble/setup.bash

echo "=== Build ==="
colcon build --packages-select bulldog_drawer
source install/setup.bash

IMAGE="${ROOT}/src/bulldog_drawer/images/bulldog.png"
OUT="${ROOT}/output/images"

echo "=== Gerando imagens do pipeline em ${OUT} ==="
python3 scripts/visualize_pipeline.py "$IMAGE" --output-dir "$OUT"

echo "=== Iniciando turtlesim (fundo) ==="
pkill -f turtlesim_node 2>/dev/null || true
sleep 1
ros2 run turtlesim turtlesim_node &
TURTLE_PID=$!
sleep 3

echo "=== Desenhando contorno no turtlesim ==="
ros2 run bulldog_drawer draw_contour --ros-args \
  -p subsample_step:=5 -p simplify_epsilon:=2.0 \
  -p linear_speed:=2.5 -p goal_tolerance:=0.06 -p angular_gain:=2.0

echo ""
echo "Pronto!"
echo "  Imagens: ${OUT}/"
echo "    01_original  02_grayscale  03_sobel  04_threshold"
echo "    05_contornos_detectados  06_pipeline_grid  07_contour_overlay  08_turtlesim_path"
echo "  Turtlesim: janela aberta com o desenho (feche manualmente ou: kill ${TURTLE_PID})"
