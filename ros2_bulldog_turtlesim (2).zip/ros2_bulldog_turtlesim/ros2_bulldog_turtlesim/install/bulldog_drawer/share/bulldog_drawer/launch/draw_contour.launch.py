from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "image_path",
                default_value="",
                description="Caminho absoluto para a imagem de entrada",
            ),
            Node(
                package="turtlesim",
                executable="turtlesim_node",
                name="turtlesim",
                output="screen",
            ),
            TimerAction(
                period=3.0,
                actions=[
                    Node(
                        package="bulldog_drawer",
                        executable="draw_contour",
                        name="contour_drawer",
                        output="screen",
                        parameters=[{"image_path": LaunchConfiguration("image_path")}],
                    ),
                ],
            ),
        ]
    )
